# Modelos de Mensagens para o Cursor (Copiar/Colar)

> Use estes comandos exatamente como abaixo para acionar comportamentos controlados pelo `.cursorrules`.

---

## 1) Solicitar Plano
```
PLAN
Contexto: <descreva o problema/objetivo em 1-3 frases>
Escopo: <arquivos/pastas permitidos>
Restrições: <p. ex., não alterar dependências, não tocar em build/deploy>
Saídas esperadas: <ex.: diffs, testes, docs>
```

## 2) Aprovar e Aplicar o Plano
```
APPLY PLAN
(Se precisar) BRANCH: <nome-da-branch>
Observações finais: <itens adicionais/limites>
```

## 3) Editar Arquivos Específicos (sem plano)
```
EDIT
Alvos:
- <caminho/arquivo>: <descrição breve da mudança>
- <caminho/arquivo>: <descrição breve da mudança>
Restrições: <ex.: não mexer em outras áreas>
Saídas: mostrar apenas diffs por arquivo.
```

## 4) Refatorar sem mudar API pública
```
REFACTOR
Objetivo: <ex.: reduzir complexidade ciclomática>
Escopo: <arquivos/módulos>
Restrições: manter API pública; sem dependências novas.
Testes: garantir que permanecem verdes.
```

## 5) Testes
```
TEST
Objetivo: <o que validar>
Escopo: <unidade/integrado/e2e>
Observação: apenas gerar código de teste e instruções de execução. Não executar.
```

## 6) Documentação
```
DOCS
Objetivo: <o que documentar>
Arquivos: <README.md, CHANGELOG.md, docs/*.md>
Estilo: conciso, PT-BR.
```

## 7) Branch
```
BRANCH: feature/<slug-curto>
```

## 8) Commit (apenas local; não fazer push)
```
COMMIT: <tipo>(<escopo opcional>): <mensagem curta>
Exemplos:
- feat(auth): add OAuth device flow
- fix(api): handle null on user DTO
- docs(readme): quick start for Windows
```

## 9) Push
```
PUSH
```

## 10) Reverter e Abortar
```
REVERT
```
```
ABORT
```

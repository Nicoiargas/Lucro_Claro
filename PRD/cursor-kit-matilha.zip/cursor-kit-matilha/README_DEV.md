# Fluxo de Trabalho com Cursor — Matilha

Este repositório usa um `.cursorrules` para garantir **segurança, previsibilidade e economia de tokens**.
A automação **não faz commit/push** sem sua ordem explícita.

## 1. Princípios
- Alterações **mínimas e atômicas** com diffs por arquivo.
- **Plano antes de editar** (salvo operações triviais via `EDIT`).
- **Sem ações destrutivas**: nada de apagar/mover grandes pastas sem aprovação.
- **Sem redes/execução real**: o agente gera instruções; você decide executar.

## 2. Comandos-Chave (copiar/colar)
- `PLAN` → Cursor propõe passos, arquivos, riscos e saídas.
- `APPLY PLAN` → Autoriza aplicar o plano aprovado (opcionalmente com `BRANCH:`).
- `EDIT` → Mudanças pontuais em arquivos especificados.
- `REFACTOR` → Refatoração sem quebrar API pública.
- `TEST` → Gera testes e instruções de execução (não executa).
- `DOCS` → Atualiza documentação.
- `COMMIT: <mensagem>` → Faz commit local (Conventional Commits).
- `PUSH` → Faz push da branch atual.
- `REVERT` / `ABORT` → Desfaz/para.

> Modelos prontos em `CURSOR_MESSAGE_TEMPLATES.md`.

## 3. Branches e Commits
- **Nome de branch**: `feature/<slug>`, `fix/<slug>`, `chore/<slug>`.
- **Conventional Commits**: `feat:`, `fix:`, `docs:`, `chore:`, `refactor:`, `test:`, `build:`, `ci:`.
- **Um commit por assunto**; evite commits gigantes.

## 4. Qualidade
- Respeitar ESLint/Prettier/EditorConfig existentes.
- Tipagem estrita quando possível; sem quebra de API.
- Cobrir caminho feliz + casos de borda quando tocar lógica.
- Mensagens de erro claras (sem segredos).

## 5. Segurança
- Nunca expor `secrets`/tokens em código, logs ou docs.
- Não alterar `.env`, deploy, CI/CD sem aprovação explícita.
- Cuidado com SSRF/RCE/XSS e validação de inputs.

## 6. Antiloop e Economia de Tokens
- No máximo **2 tentativas** por erro. Se persistir, o Cursor **para** e pede instrução.
- Explicar suposições; propor melhores alternativas quando faltar contexto.
- Preferir **diffs enxutos** e mudanças locais.

## 7. Quando Parar
- Ambiguidade de requisitos.
- Risco a dados/produção.
- Falhas repetidas (2x) no mesmo ponto.

## 8. Quick Start
1. Coloque `.cursorrules` na raiz do repo.
2. Adicione `.cursorignore` para reduzir ruído.
3. Guarde `CURSOR_MESSAGE_TEMPLATES.md` na raiz (ou `docs/`).
4. Use `PLAN` → revise → `APPLY PLAN` para executar.
5. Termine com `COMMIT:` e, se OK, `PUSH`.

---

Dúvidas rápidas? Cole: `PLAN` e descreva contexto/arquivos/limites.
